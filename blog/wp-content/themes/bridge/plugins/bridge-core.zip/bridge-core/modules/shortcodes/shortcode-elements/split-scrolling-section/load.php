<?php

include_once BRIDGE_CORE_SHORTCODES_PATH . '/split-scrolling-section/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/split-scrolling-section/split-scrolling-section.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/split-scrolling-section/split-scrolling-section-left-panel.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/split-scrolling-section/split-scrolling-section-right-panel.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/split-scrolling-section/split-scrolling-section-content-item.php';